<?php    
// Koneksi ke database    
$host = "localhost";    
$username = "root";    
$password = "";    
$database = "perpustakaan";    
    
try {    
    $conn = new mysqli($host, $username, $password, $database);    
    if ($conn->connect_error) {    
        throw new Exception("Koneksi gagal: " . $conn->connect_error);    
    }    
} catch (Exception $e) {    
    die("Error: " . $e->getMessage());    
}    
    
// Fungsi untuk menjalankan query dengan prepared statements    
function query($sql, $params = []) {    
    global $conn;    
    $stmt = $conn->prepare($sql);    
    if (!$stmt) {    
        throw new Exception("Query preparation failed: " . $conn->error);    
    }    
    if (!empty($params)) {    
        $types = str_repeat('s', count($params)); // Semua parameter dianggap string    
        $stmt->bind_param($types, ...$params);    
    }    
    $stmt->execute();    
    $result = $stmt->get_result();    
    $stmt->close();    
    return $result;    
}    
    
// Fungsi untuk membuat tombol kembali ke halaman utama    
function backToHome() {    
    echo "<br><a class='back-link' href='index.php'>Kembali ke Halaman Utama</a><br><br>";    
}    
    
// Tampilan halaman awal    
if (!isset($_GET['page'])) {    
    echo "<h1>Selamat datang di Sistem Perpustakaan</h1>";    
    echo "<a href='?page=anggota' class='dashboard-link'>Kelola Anggota</a> | ";    
    echo "<a href='?page=buku' class='dashboard-link'>Kelola Buku</a> | ";    
    echo "<a href='?page=peminjaman' class='dashboard-link'>Kelola Peminjaman</a>";    
    exit;    
}    
    
$page = $_GET['page'];    
    
// Menghubungkan dengan CSS    
echo '<style>  
        body {  
            font-family: Arial, sans-serif;  
            background-color: #f4f4f9;  
            margin: 0;  
            padding: 0;  
        }  
        h1 {  
            text-align: center;  
            margin-top: 20px;  
            color: #333;  
        }  
        table {  
            width: 80%;  
            margin: 20px auto;  
            border-collapse: collapse;  
            box-shadow: 0 2px 3px rgba(0,0,0,0.1);  
        }  
        th, td {  
            padding: 12px;  
            text-align: left;  
            border-bottom: 1px solid #ddd;  
        }  
        th {  
            background-color: #4CAF50;  
            color: white;  
        }  
        tr:hover {  
            background-color: #f1f1f1;  
        }  
        .dashboard-link {  
            display: inline-block;  
            margin: 10px;  
            padding: 10px 20px;  
            background-color: #4CAF50;  
            color: white;  
            text-decoration: none;  
            border-radius: 5px;  
            transition: background-color 0.3s;  
        }  
        .dashboard-link:hover {  
            background-color: #45a049;  
        }  
        .back-link {  
            display: block;  
            margin: 20px auto;  
            padding: 10px 20px;  
            background-color: #008CBA;  
            color: white;  
            text-align: center;  
            text-decoration: none;  
            border-radius: 5px;  
            transition: background-color 0.3s;  
        }  
        .back-link:hover {  
            background-color: #007bb5;  
        }  
        form {  
            width: 80%;  
            margin: 20px auto;  
            padding: 20px;  
            background-color: #fff;  
            box-shadow: 0 2px 3px rgba(0,0,0,0.1);  
            border-radius: 5px;  
        }  
        input[type="text"], input[type="number"], input[type="date"] {  
            width: 100%;  
            padding: 10px;  
            margin: 10px 0;  
            border: 1px solid #ccc;  
            border-radius: 5px;  
        }  
        button {  
            width: 100%;  
            padding: 10px;  
            background-color: #4CAF50;  
            color: white;  
            border: none;  
            border-radius: 5px;  
            cursor: pointer;  
            transition: background-color 0.3s;  
        }  
        button:hover {  
            background-color: #45a049;  
        }  
    </style>';    
    
try {    
    if ($page === 'anggota') {    
        // Menampilkan anggota    
        echo "<h1>Daftar Anggota</h1>";    
        $result = query("SELECT * FROM Anggota");    
        echo "<table>    
                <tr>    
                    <th>ID</th>    
                    <th>Nama</th>    
                    <th>Alamat</th>    
                    <th>Telepon</th>    
                    <th>Aksi</th>    
                </tr>";    
        while ($row = $result->fetch_assoc()) {    
            echo "<tr>    
                    <td>{$row['ID_Anggota']}</td>    
                    <td>{$row['Nama']}</td>    
                    <td>{$row['Alamat']}</td>    
                    <td>{$row['Telepon']}</td>    
                    <td><a href='?page=edit_anggota&id={$row['ID_Anggota']}' class='dashboard-link'>Edit</a> | <a href='?page=delete_anggota&id={$row['ID_Anggota']}' class='dashboard-link'>Hapus</a></td>    
                  </tr>";    
        }    
        echo "</table><a href='?page=add_anggota' class='dashboard-link'>Tambah Anggota</a>";    
        backToHome();    
    } elseif ($page === 'add_anggota') {    
        // Form tambah anggota    
        echo "<h1>Tambah Anggota</h1>    
              <form method='POST' action='?page=save_anggota'>    
                Nama: <input type='text' name='Nama' required><br>    
                Alamat: <input type='text' name='Alamat' required><br>    
                Telepon: <input type='text' name='Telepon' required><br>    
                <button type='submit'>Simpan</button>    
              </form>";    
        backToHome();    
    } elseif ($page === 'save_anggota') {    
        // Menyimpan data anggota baru    
        $nama = htmlspecialchars($_POST['Nama']);    
        $alamat = htmlspecialchars($_POST['Alamat']);    
        $telepon = htmlspecialchars($_POST['Telepon']);    
        query("INSERT INTO Anggota (Nama, Alamat, Telepon) VALUES (?, ?, ?)", [$nama, $alamat, $telepon]);    
        echo "<p>Anggota berhasil ditambahkan.</p>";    
        backToHome();    
    } elseif ($page === 'buku') {    
        // Menampilkan buku    
        echo "<h1>Daftar Buku</h1>";    
        $result = query("SELECT * FROM Buku");    
        echo "<table>    
                <tr>    
                    <th>ID</th>    
                    <th>Judul</th>    
                    <th>Pengarang</th>    
                    <th>Tahun</th>    
                    <th>Stok</th>    
                    <th>Aksi</th>    
                </tr>";    
        while ($row = $result->fetch_assoc()) {    
            echo "<tr>    
                    <td>{$row['ID_Buku']}</td>    
                    <td>{$row['Judul']}</td>    
                    <td>{$row['Pengarang']}</td>    
                    <td>{$row['Tahun']}</td>    
                    <td>{$row['Stok']}</td>    
                    <td><a href='?page=edit_buku&id={$row['ID_Buku']}' class='dashboard-link'>Edit</a> | <a href='?page=delete_buku&id={$row['ID_Buku']}' class='dashboard-link'>Hapus</a></td>    
                  </tr>";    
        }    
        echo "</table><a href='?page=add_buku' class='dashboard-link'>Tambah Buku</a>";    
        backToHome();    
    } elseif ($page === 'add_buku') {    
        // Form tambah buku    
        echo "<h1>Tambah Buku</h1>    
              <form method='POST' action='?page=save_buku'>    
                Judul: <input type='text' name='Judul' required><br>    
                Pengarang: <input type='text' name='Pengarang' required><br>    
                Tahun: <input type='number' name='Tahun' required><br>    
                Stok: <input type='number' name='Stok' required><br>    
                <button type='submit'>Simpan</button>    
              </form>";    
        backToHome();    
    } elseif ($page === 'save_buku') {    
        // Menyimpan data buku baru    
        $judul = htmlspecialchars($_POST['Judul']);    
        $pengarang = htmlspecialchars($_POST['Pengarang']);    
        $tahun = intval($_POST['Tahun']);    
        $stok = intval($_POST['Stok']);    
        query("INSERT INTO Buku (Judul, Pengarang, Tahun, Stok) VALUES (?, ?, ?, ?)", [$judul, $pengarang, $tahun, $stok]);    
        echo "<p>Buku berhasil ditambahkan.</p>";    
        backToHome();    
    } elseif ($page === 'peminjaman') {    
        // Menampilkan peminjaman    
        echo "<h1>Daftar Peminjaman</h1>";    
        $result = query("SELECT p.ID_Peminjaman, a.Nama, b.Judul, p.Tanggal_Pinjam, p.Tanggal_Kembali     
                         FROM Peminjaman p    
                         JOIN Anggota a ON p.ID_Anggota = a.ID_Anggota    
                         JOIN Buku b ON p.ID_Buku = b.ID_Buku");    
        echo "<table>    
                <tr>    
                    <th>ID</th>    
                    <th>Nama Anggota</th>    
                    <th>Judul Buku</th>    
                    <th>Tanggal Pinjam</th>    
                    <th>Tanggal Kembali</th>    
                    <th>Aksi</th>    
                </tr>";    
        while ($row = $result->fetch_assoc()) {    
            echo "<tr>    
                    <td>{$row['ID_Peminjaman']}</td>    
                    <td>{$row['Nama']}</td>    
                    <td>{$row['Judul']}</td>    
                    <td>{$row['Tanggal_Pinjam']}</td>    
                    <td>{$row['Tanggal_Kembali']}</td>    
                    <td><a href='?page=delete_peminjaman&id={$row['ID_Peminjaman']}' class='dashboard-link'>Hapus</a></td>    
                  </tr>";    
        }    
        echo "</table><a href='?page=add_peminjaman' class='dashboard-link'>Tambah Peminjaman</a>";    
        backToHome();    
    } elseif ($page === 'add_peminjaman') {    
        // Form tambah peminjaman    
        echo "<h1>Tambah Peminjaman</h1>    
              <form method='POST' action='?page=save_peminjaman'>    
                ID Anggota: <input type='number' name='ID_Anggota' required><br>    
                ID Buku: <input type='number' name='ID_Buku' required><br>    
                Tanggal Pinjam: <input type='date' name='Tanggal_Pinjam' required><br>    
                Tanggal Kembali: <input type='date' name='Tanggal_Kembali' required><br>    
                <button type='submit'>Simpan</button>    
              </form>";    
        backToHome();    
    } elseif ($page === 'save_peminjaman') {    
        // Menyimpan data peminjaman baru    
        $id_anggota = intval($_POST['ID_Anggota']);    
        $id_buku = intval($_POST['ID_Buku']);    
        $tanggal_pinjam = htmlspecialchars($_POST['Tanggal_Pinjam']);    
        $tanggal_kembali = htmlspecialchars($_POST['Tanggal_Kembali']);    
        query("INSERT INTO Peminjaman (ID_Anggota, ID_Buku, Tanggal_Pinjam, Tanggal_Kembali) VALUES (?, ?, ?, ?)", [$id_anggota, $id_buku, $tanggal_pinjam, $tanggal_kembali]);    
        echo "<p>Peminjaman berhasil ditambahkan.</p>";    
        backToHome();    
    }    
} catch (Exception $e) {    
    die("Error: " . $e->getMessage());    
}    
    
$conn->close();    
?>  
